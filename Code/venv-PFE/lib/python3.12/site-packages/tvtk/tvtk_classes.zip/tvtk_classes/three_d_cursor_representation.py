# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.widget_representation import WidgetRepresentation


class ThreeDCursorRepresentation(WidgetRepresentation):
    r"""
    ThreeDCursorRepresentation - Representation of the ThreeDCursorWidget
    
    Superclass: WidgetRepresentation
    
    Internally, the class uses a HardwarePicker to pick the position
    of the cursor in the scene given a display position (in pixels). If
    the mouse hovers an actor, the cursor is placed on its surface. If
    not, it's placed on the focal plane of the camera. Because of the
    current state of pickers in VTK, this cursor do not support
    volumetric data.
    
    The cursor itself can be considered as a self-employed widget handle.
    For resizing the cursor, use the set_handle_size method of this widget.
    
    Current limitations :
    - Do not work with volumes (for now no pickers handles them properly)
    - Unsteady placement on other widgets (manipulation and cursor
      actualization remain fine)
    - When zooming the cursor do not follows the mouse until moving it
      again
    
    @sa ThreeDCursorWidget
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtk3DCursorRepresentation, obj, update, **traits)
    
    def _get_cursor(self):
        return wrap_vtk(self._vtk_obj.GetCursor())
    def _set_cursor(self, arg):
        old_val = self._get_cursor()
        self._wrap_call(self._vtk_obj.SetCursor,
                        deref_vtk(arg))
        self.trait_property_changed('cursor', old_val, arg)
    cursor = traits.Property(_get_cursor, _set_cursor, desc=\
        r"""
        
        """
    )

    def _get_custom_cursor(self):
        return wrap_vtk(self._vtk_obj.GetCustomCursor())
    def _set_custom_cursor(self, arg):
        old_val = self._get_custom_cursor()
        self._wrap_call(self._vtk_obj.SetCustomCursor,
                        deref_vtk(arg))
        self.trait_property_changed('custom_cursor', old_val, arg)
    custom_cursor = traits.Property(_get_custom_cursor, _set_custom_cursor, desc=\
        r"""
        
        """
    )

    def _get_shape(self):
        return self._vtk_obj.GetShape()
    shape = traits.Property(_get_shape, desc=\
        r"""
        
        """
    )

    def set_cursor_shape(self, *args):
        """
        set_cursor_shape(self, shape:int) -> None
        C++: void set_cursor_shape(int shape)
        Set / Get the shape of the cursor. You can choose between CROSS,
        SPHERE and CUSTOM. Choose CUSTOM if you want to use the actor you
        pass with set_custom_cursor.
        """
        ret = self._wrap_call(self._vtk_obj.SetCursorShape, *args)
        return ret

    _updateable_traits_ = \
    (('need_to_render', 'GetNeedToRender'), ('picking_managed',
    'GetPickingManaged'), ('dragable', 'GetDragable'), ('pickable',
    'GetPickable'), ('use_bounds', 'GetUseBounds'), ('visibility',
    'GetVisibility'), ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('handle_size', 'GetHandleSize'),
    ('place_factor', 'GetPlaceFactor'), ('estimated_render_time',
    'GetEstimatedRenderTime'), ('render_time_multiplier',
    'GetRenderTimeMultiplier'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'dragable', 'global_warning_display', 'need_to_render',
    'pickable', 'picking_managed', 'use_bounds', 'visibility',
    'estimated_render_time', 'handle_size', 'object_name', 'place_factor',
    'render_time_multiplier'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(ThreeDCursorRepresentation, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit ThreeDCursorRepresentation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['need_to_render', 'picking_managed', 'use_bounds',
            'visibility'], [], ['estimated_render_time', 'handle_size',
            'object_name', 'place_factor', 'render_time_multiplier']),
            title='Edit ThreeDCursorRepresentation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit ThreeDCursorRepresentation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

