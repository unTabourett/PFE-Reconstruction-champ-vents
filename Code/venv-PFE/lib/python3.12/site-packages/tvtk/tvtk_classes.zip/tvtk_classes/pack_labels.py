# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.data_set_algorithm import DataSetAlgorithm


class PackLabels(DataSetAlgorithm):
    r"""
    PackLabels - renumber segmentation labels into contiguous runs of
    (potentially) smaller type
    
    Superclass: DataSetAlgorithm
    
    PackLabels is a filter that renumbers a set of segmentation labels
    into a contiguous sequence of label values. The input segmentation
    labels are represented by a scalar array of arbitrary type, and the
    labels may be non-contiguous (i.e., there may be "gaps" in the labels
    used to annotate structured in the segmentation). After execution,
    the output of this filter consists of (by default) an output of the
    same dataset type as the input; however the labels are renumbered so
    that they are contiguous (starting with value==0,
    [0,number_of_labels)). After filter execution, an array of labels
    present in the input can be retrieved (named "packed_labels"), listed
    in ascending order, this is useful in various filters such as
    discrete isocontouring filters which require iso/label-values (e.g.,
    SurfaceNets3D).
    
    Note that this filter mostly works on input dataset types of
    ImageData (segmentation maps are commonly used in medical
    computing). However, because this filter operates on scalar point or
    cell data independent of dataset type, it has been generalized to
    work on any dataset type.
    
    The filter also converts the input data from one type to another. By
    default, the output labels are of an unsigned integral type large
    enough to represent the N packed label values. It is also possible to
    explicitly specify the type of the output annotation/label image.
    This conversion capability often reduces the size of the output
    image, and can be used is useful when an algorithm performs better,
    or requires, a certain type of input data. Note however, that manual
    specification can be dangerous: trying to pack a large number of
    labels into a manually specified reduced precision label values may
    result in setting some label values to the background_value.
    
    Finally, in advanced usage, it is possible to control how sorting of
    the output labels is performed. By default, the labels are assorted
    based on their associated input label values (sort_by_label_value).
    However, it is possible to arrange the labels based on their
    frequency of use (sort_by_label_count). Sorting is useful for gathering
    data statistics, or to extract and display the segmented objects that
    are the "largest" in the dataset.
    
    @sa
    SurfaceNets3D SurfaceNets2D DiscreteFlyingEdges3D
    DiscreteMarchingCubes
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPackLabels, obj, update, **traits)
    
    pass_cell_data = tvtk_base.true_bool_trait(desc=\
        r"""
        
        """
    )

    def _pass_cell_data_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPassCellData,
                        self.pass_cell_data_)

    pass_field_data = tvtk_base.true_bool_trait(desc=\
        r"""
        
        """
    )

    def _pass_field_data_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPassFieldData,
                        self.pass_field_data_)

    pass_point_data = tvtk_base.true_bool_trait(desc=\
        r"""
        Indicate whether to pass point data, cell data, and/or field data
        through to the output. This can be useful to limit the data being
        processed down a pipeline, including writing output files. By
        default, point data and cell data is passed from input to output.
        """
    )

    def _pass_point_data_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPassPointData,
                        self.pass_point_data_)

    def get_output_scalar_type(self):
        """
        get_output_scalar_type(self) -> int
        C++: virtual int get_output_scalar_type()"""
        ret = self._vtk_obj.GetOutputScalarType()
        return ret
        

    def set_output_scalar_type(self, *args):
        """
        set_output_scalar_type(self, _arg:int) -> None
        C++: virtual void set_output_scalar_type(int _arg)"""
        ret = self._wrap_call(self._vtk_obj.SetOutputScalarType, *args)
        return ret

    def set_output_scalar_type_to_default(self):
        """
        set_output_scalar_type_to_default(self) -> None
        C++: void set_output_scalar_type_to_default()"""
        self._vtk_obj.SetOutputScalarTypeToDefault()

    def set_output_scalar_type_to_unsigned_char(self):
        """
        set_output_scalar_type_to_unsigned_char(self) -> None
        C++: void set_output_scalar_type_to_unsigned_char()"""
        self._vtk_obj.SetOutputScalarTypeToUnsignedChar()

    def set_output_scalar_type_to_unsigned_int(self):
        """
        set_output_scalar_type_to_unsigned_int(self) -> None
        C++: void set_output_scalar_type_to_unsigned_int()"""
        self._vtk_obj.SetOutputScalarTypeToUnsignedInt()

    def set_output_scalar_type_to_unsigned_long(self):
        """
        set_output_scalar_type_to_unsigned_long(self) -> None
        C++: void set_output_scalar_type_to_unsigned_long()"""
        self._vtk_obj.SetOutputScalarTypeToUnsignedLong()

    def set_output_scalar_type_to_unsigned_short(self):
        """
        set_output_scalar_type_to_unsigned_short(self) -> None
        C++: void set_output_scalar_type_to_unsigned_short()"""
        self._vtk_obj.SetOutputScalarTypeToUnsignedShort()

    background_value = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Specify a background label value. This value is used when the ith
        label is i >= N where N is the number of labels that the
        output_scalar_type can represent. So for example, when trying to
        pack 500 labels into an unsigned char output scalar type, all i
        labels i>=256 would be set to this background value. By default
        the background_value == 0.
        """
    )

    def _background_value_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetBackgroundValue,
                        self.background_value)

    sort_by = traits.Trait(0, traits.Range(0, 1, enter_set=True, auto_set=False), desc=\
        r"""
        Indicate whether to sort the output labels by their input scalars
        label value (sort_by_label_value), or to sort by the frequency of
        occurence of the label values(sort_by_label_count). By default,
        sorting is performed by label value.  Note that typically the
        background label has the highest frequency of occurence, with a
        label value == 0 (but this is not a guarantee).
        """
    )

    def _sort_by_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSortBy,
                        self.sort_by)

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input data object. This method is not recommended for
        use, but lots of old style filters use it.
        """
    )

    def _get_labels(self):
        return wrap_vtk(self._vtk_obj.GetLabels())
    labels = traits.Property(_get_labels, desc=\
        r"""
        Return the number of and list of labels found in the input label
        map. The methods return a DataArray with the same data type as
        the input scalar type. By default, the labels are sorted in
        ascending order based on the input data (label) values (i.e.,
        sort_by_label_value). However, if sort_by_label_count is specified,
        then the labels are sorted in descending order based on their
        frequency of occurrence (i.e., their counts).
        """
    )

    def _get_labels_count(self):
        return wrap_vtk(self._vtk_obj.GetLabelsCount())
    labels_count = traits.Property(_get_labels_count, desc=\
        r"""
        Return the frequency of occurence (i.e., the count) of each label
        returned in the labels_array. The methods returns a IdTypeArray
        that is implicitly ordered consistent with the labels_array (i.e.,
        labels_count[i] gives the frequency count for labels_array[i]).
        Note that if sort_by_label_count is set, then the labels array and
        labels count are sorted in descending order based on the
        frequency of occurrence of labels. If sort_by_label_value is set,
        then the labels array and label counts are sorted in ascending
        order based on input label values. Also note that the size of the
        labels_count array is identical to the size of the labels_count
        array.
        """
    )

    def _get_number_of_labels(self):
        return self._vtk_obj.GetNumberOfLabels()
    number_of_labels = traits.Property(_get_number_of_labels, desc=\
        r"""
        
        """
    )

    def sort_by_label_count(self):
        """
        sort_by_label_count(self) -> None
        C++: void sort_by_label_count()"""
        ret = self._vtk_obj.SortByLabelCount()
        return ret
        

    def sort_by_label_value(self):
        """
        sort_by_label_value(self) -> None
        C++: void sort_by_label_value()"""
        ret = self._vtk_obj.SortByLabelValue()
        return ret
        

    _updateable_traits_ = \
    (('pass_cell_data', 'GetPassCellData'), ('pass_field_data',
    'GetPassFieldData'), ('pass_point_data', 'GetPassPointData'),
    ('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('background_value', 'GetBackgroundValue'), ('sort_by', 'GetSortBy'),
    ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'pass_cell_data', 'pass_field_data', 'pass_point_data',
    'release_data_flag', 'abort_output', 'background_value',
    'object_name', 'progress_text', 'sort_by'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(PackLabels, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit PackLabels properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['pass_cell_data', 'pass_field_data', 'pass_point_data'], [],
            ['abort_output', 'background_value', 'object_name', 'sort_by']),
            title='Edit PackLabels properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit PackLabels properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

