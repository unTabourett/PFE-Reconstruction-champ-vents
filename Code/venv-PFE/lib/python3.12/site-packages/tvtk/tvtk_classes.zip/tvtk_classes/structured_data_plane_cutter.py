# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.poly_data_algorithm import PolyDataAlgorithm


class StructuredDataPlaneCutter(PolyDataAlgorithm):
    r"""
    StructuredDataPlaneCutter - fast plane cutting of
    ImageData/vtkRectilinearGrid/vtkStructuredGrid
    
    Superclass: PolyDataAlgorithm
    
    StructuredDataPlaneCutter is a specialized filter that cuts an
    input ImageData/vtkRectilinearGrid/vtkStructuredGrid. The filter
    is designed for high speed.
    
    To use this filter you must specify an input
    ImageData/vtkRectilinearGrid/ StructuredGrid and a plane to cut
    with.
    
    This algorithm is linear with regard to cells. Tt may build (in a
    preprocessing step) a spatial search structure that accelerates the
    plane cuts. The search structure, which is typically a sphere tree,
    is used to quickly cull candidate cells.
    
    @warning
    This filter delegates to FlyingEdgesPlaneCutter for ImageData
    if you DON'T want to generate polygons.
    
    @warning
    This class is templated. It may run slower than serial execution if
    the code is not optimized during compilation. Build in Release or
    release_with_debug_info.
    
    @warning
    This class has been threaded with SMPTools. Using TBB or other
    non-sequential type (set in the CMake variable
    VTK_SMP_IMPLEMENTATION_TYPE) may improve performance significantly.
    
    @sa
    Cutter PlaneCutter FlyingEdgesPlaneCutter
    ThreeDLinearGridPlaneCutter PolyDataPlaneCutter
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkStructuredDataPlaneCutter, obj, update, **traits)
    
    build_hierarchy = tvtk_base.true_bool_trait(desc=\
        r"""
        Indicate whether to build tree hierarchy. Computing the tree
        hierarchy can take some time on the first computation but if the
        input does not change, the computation of all further slice will
        be faster.
        
        Default is on.
        """
    )

    def _build_hierarchy_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetBuildHierarchy,
                        self.build_hierarchy_)

    build_tree = tvtk_base.true_bool_trait(desc=\
        r"""
        Indicate whether to build the sphere tree. Computing the sphere
        will take some time on the first computation but if the input
        does not change, the computation of all further slice will be
        much faster.
        
        Default is on.
        """
    )

    def _build_tree_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetBuildTree,
                        self.build_tree_)

    compute_normals = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get the computation of normals. The normal generated is
        simply the cut plane normal.
        
        Default is off.
        """
    )

    def _compute_normals_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeNormals,
                        self.compute_normals_)

    generate_polygons = tvtk_base.true_bool_trait(desc=\
        r"""
        Indicate whether to generate polygons instead of triangles
        
        Default is on.
        """
    )

    def _generate_polygons_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetGeneratePolygons,
                        self.generate_polygons_)

    interpolate_attributes = tvtk_base.true_bool_trait(desc=\
        r"""
        Indicate whether to interpolate attribute data. Note that both
        cell data and point data is interpolated and output
        
        Default is on.
        """
    )

    def _interpolate_attributes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetInterpolateAttributes,
                        self.interpolate_attributes_)

    batch_size = traits.Trait(1000, traits.Range(1, 2147483647, enter_set=True, auto_set=False), desc=\
        r"""
        Specify the number of input cells in a batch, where a batch
        defines a subset of the input cells operated on during threaded
        execution. Generally this is only used for debugging or
        performance studies (since batch size affects the thread
        workload).
        
        Default is 1000.
        """
    )

    def _batch_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetBatchSize,
                        self.batch_size)

    output_points_precision = traits.Trait(2, traits.Range(0, 2, enter_set=True, auto_set=False), desc=\
        r"""
        Set/get the desired precision for the output types. See the
        documentation for the Algorithm::DesiredOutputPrecision enum
        for an explanation of the available precision settings.
        """
    )

    def _output_points_precision_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOutputPointsPrecision,
                        self.output_points_precision)

    def _get_plane(self):
        return wrap_vtk(self._vtk_obj.GetPlane())
    def _set_plane(self, arg):
        old_val = self._get_plane()
        self._wrap_call(self._vtk_obj.SetPlane,
                        deref_vtk(arg))
        self.trait_property_changed('plane', old_val, arg)
    plane = traits.Property(_get_plane, _set_plane, desc=\
        r"""
        
        """
    )

    def _get_sphere_tree(self):
        return wrap_vtk(self._vtk_obj.GetSphereTree())
    def _set_sphere_tree(self, arg):
        old_val = self._get_sphere_tree()
        self._wrap_call(self._vtk_obj.SetSphereTree,
                        deref_vtk(arg))
        self.trait_property_changed('sphere_tree', old_val, arg)
    sphere_tree = traits.Property(_get_sphere_tree, _set_sphere_tree, desc=\
        r"""
        
        """
    )

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self) -> DataObject
        C++: DataObject *get_input()
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('build_hierarchy', 'GetBuildHierarchy'), ('build_tree',
    'GetBuildTree'), ('compute_normals', 'GetComputeNormals'),
    ('generate_polygons', 'GetGeneratePolygons'),
    ('interpolate_attributes', 'GetInterpolateAttributes'),
    ('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('batch_size',
    'GetBatchSize'), ('output_points_precision',
    'GetOutputPointsPrecision'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'build_hierarchy', 'build_tree', 'compute_normals',
    'debug', 'generate_polygons', 'global_warning_display',
    'interpolate_attributes', 'release_data_flag', 'abort_output',
    'batch_size', 'object_name', 'output_points_precision',
    'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(StructuredDataPlaneCutter, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit StructuredDataPlaneCutter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['build_hierarchy', 'build_tree', 'compute_normals',
            'generate_polygons', 'interpolate_attributes'], [], ['abort_output',
            'batch_size', 'object_name', 'output_points_precision']),
            title='Edit StructuredDataPlaneCutter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit StructuredDataPlaneCutter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

