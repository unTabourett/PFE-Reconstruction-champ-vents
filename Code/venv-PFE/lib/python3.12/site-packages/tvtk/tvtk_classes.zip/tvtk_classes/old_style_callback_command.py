# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.command import Command


class OldStyleCallbackCommand(Command):
    r"""
    OldStyleCallbackCommand - supports legacy function callbacks for
    VTK
    
    Superclass: Command
    
    OldStyleCallbackCommand is a callback that supports the legacy
    callback methods found in VTK. For example, the legacy method
    ProcessObject::SetStartMethod() is actually invoked using the
    command/observer design pattern of VTK, and the
    OldStyleCallbackCommand is used to provide the legacy
    functionality. The callback function should have the form void
    func(void *clientdata), where clientdata is special data that should
    is associated with this instance of CallbackCommand.
    
    @warning
    This is legacy glue. Please do not use; it will be eventually
    eliminated.
    
    @sa
    Command CallbackCommand
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkOldStyleCallbackCommand, obj, update, **traits)
    
    def set_client_data(self, *args):
        """
        set_client_data(self, cd:Pointer) -> None
        C++: void set_client_data(void *cd)
        Methods to set and get client and callback information.
        """
        ret = self._wrap_call(self._vtk_obj.SetClientData, *args)
        return ret

    _updateable_traits_ = \
    (('abort_flag', 'GetAbortFlag'), ('passive_observer',
    'GetPassiveObserver'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_flag', 'passive_observer'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(OldStyleCallbackCommand, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit OldStyleCallbackCommand properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['abort_flag', 'passive_observer'], [], []),
            title='Edit OldStyleCallbackCommand properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit OldStyleCallbackCommand properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

