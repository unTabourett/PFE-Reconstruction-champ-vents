# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.unstructured_grid_volume_ray_integrator import UnstructuredGridVolumeRayIntegrator


class UnstructuredGridPartialPreIntegration(UnstructuredGridVolumeRayIntegrator):
    r"""
    UnstructuredGridPartialPreIntegration - performs piecewise linear
    ray integration.
    
    Superclass: UnstructuredGridVolumeRayIntegrator
    
    UnstructuredGridPartialPreIntegration performs piecewise linear
    ray integration.  This will give the same results as
    UnstructuredGridLinearRayIntegration (with potentially a error due
    to table lookup quantization), but should be notably faster.  The
    algorithm used is given by Moreland and Angel, "A Fast High Accuracy
    Volume Renderer for Unstructured Data."
    
    This class is thread safe only after the first instance is created.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkUnstructuredGridPartialPreIntegration, obj, update, **traits)
    
    def get_psi_table(self, *args):
        """
        get_psi_table(size:int) -> Pointer
        C++: static float *get_psi_table(int &size)"""
        ret = self._wrap_call(self._vtk_obj.GetPsiTable, *args)
        return ret

    def build_psi_table(self):
        """
        build_psi_table() -> None
        C++: static void build_psi_table()"""
        ret = self._vtk_obj.BuildPsiTable()
        return ret
        

    def integrate_ray(self, *args):
        """
        integrate_ray(length:float, intensity_front:float,
            attenuation_front:float, intensity_back:float,
            attenuation_back:float, color:[float, float, float, float])
            -> None
        C++: static void integrate_ray(double length,
            double intensity_front, double attenuation_front,
            double intensity_back, double attenuation_back,
            float color[4])
        integrate_ray(length:float, color_front:(float, float, float),
            attenuation_front:float, color_back:(float, float, float),
            attenuation_back:float, color:[float, float, float, float])
            -> None
        C++: static void integrate_ray(double length,
            const double color_front[3], double attenuation_front,
            const double color_back[3], double attenuation_back,
            float color[4])
        Integrates a single ray segment.  color is blended with the
        result (with color in front).  The result is written back into
        color.
        """
        ret = self._wrap_call(self._vtk_obj.IntegrateRay, *args)
        return ret

    def psi(self, *args):
        """
        psi(taufD:float, taubD:float) -> float
        C++: static float psi(float taufD, float taubD)
        Looks up Psi (as defined by Moreland and Angel, "A Fast High
        Accuracy Volume Renderer for Unstructured Data") in a table.  The
        table must be created first, which happens on the first
        instantiation of this class or when build_psi_table is first
        called.
        """
        ret = self._wrap_call(self._vtk_obj.Psi, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(UnstructuredGridPartialPreIntegration, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit UnstructuredGridPartialPreIntegration properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit UnstructuredGridPartialPreIntegration properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit UnstructuredGridPartialPreIntegration properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

