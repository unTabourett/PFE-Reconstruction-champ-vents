# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.table_based_clip_data_set import TableBasedClipDataSet


class mClip(TableBasedClipDataSet):
    r"""
    vtkmClip - Clip a dataset using the accelerated vtk-m Clip filter.
    
    Superclass: TableBasedClipDataSet
    
    Clip a dataset using either a given value or by using an
    ImplicitFunction Currently the supported implicit functions are
    Box, Plane, and Sphere.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkmClip, obj, update, **traits)
    
    compute_scalars = tvtk_base.true_bool_trait(desc=\
        r"""
        
        """
    )

    def _compute_scalars_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeScalars,
                        self.compute_scalars_)

    force_vt_km = tvtk_base.false_bool_trait(desc=\
        r"""
        
        """
    )

    def _force_vt_km_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetForceVTKm,
                        self.force_vt_km_)

    clip_value = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _clip_value_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetClipValue,
                        self.clip_value)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)
        get_input(self) -> DataObject
        C++: DataObject *get_input()"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('compute_scalars', 'GetComputeScalars'), ('force_vt_km',
    'GetForceVTKm'), ('generate_clip_scalars', 'GetGenerateClipScalars'),
    ('generate_clipped_output', 'GetGenerateClippedOutput'),
    ('inside_out', 'GetInsideOut'), ('use_value_as_offset',
    'GetUseValueAsOffset'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('clip_value',
    'GetClipValue'), ('batch_size', 'GetBatchSize'), ('merge_tolerance',
    'GetMergeTolerance'), ('output_points_precision',
    'GetOutputPointsPrecision'), ('value', 'GetValue'), ('abort_output',
    'GetAbortOutput'), ('progress_text', 'GetProgressText'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'compute_scalars', 'debug', 'force_vt_km',
    'generate_clip_scalars', 'generate_clipped_output',
    'global_warning_display', 'inside_out', 'release_data_flag',
    'use_value_as_offset', 'abort_output', 'batch_size', 'clip_value',
    'merge_tolerance', 'object_name', 'output_points_precision',
    'progress_text', 'value'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(mClip, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit mClip properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['compute_scalars', 'force_vt_km', 'generate_clip_scalars',
            'generate_clipped_output', 'inside_out', 'use_value_as_offset'], [],
            ['abort_output', 'batch_size', 'clip_value', 'merge_tolerance',
            'object_name', 'output_points_precision', 'value']),
            title='Edit mClip properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit mClip properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

