# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.statistics_algorithm import StatisticsAlgorithm


class ExtractHistogram2D(StatisticsAlgorithm):
    r"""
    ExtractHistogram2D - compute a 2D histogram between two columns
     of an input Table.
    
    Superclass: StatisticsAlgorithm
    
    This class computes a 2D histogram between two columns of an input
     Table. Just as with a 1D histogram, a 2D histogram breaks
     up the input domain into bins, and each pair of values (row in
     the table) fits into a single bin and increments a row counter
     for that bin.
    
    
     To use this class, set the input with a table and call
    add_column_pair(nameX,nameY),
     where nameX and nameY are the names of the two columns to be used.
    
    
     In addition to the number of bins (in X and Y), the domain of
     the histogram can be customized by toggling the
    use_custom_histogram_extents
     flag and setting the custom_histogram_extents variable to the
     desired value.
    
    @sa
     PExtractHistogram2D
    
    @par Thanks:
     Developed by David Feng and Philippe Pebay at Sandia National
    Laboratories
    ----------------------------------------------------------------------
        --------
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkExtractHistogram2D, obj, update, **traits)
    
    swap_columns = tvtk_base.false_bool_trait(desc=\
        r"""
        
        """
    )

    def _swap_columns_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSwapColumns,
                        self.swap_columns_)

    use_custom_histogram_extents = tvtk_base.false_bool_trait(desc=\
        r"""
        Use the extents in custom_histogram_extents when computing the
        histogram, rather than the simple range of the input columns.
        """
    )

    def _use_custom_histogram_extents_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUseCustomHistogramExtents,
                        self.use_custom_histogram_extents_)

    scalar_type = tvtk_base.RevPrefixMap({'unsigned_int': 7, 'double': 11, 'float': 10, 'unsigned_char': 3, 'unsigned_long': 9, 'unsigned_short': 5}, default_value='unsigned_int', desc=\
        r"""
        Control the scalar type of the output histogram.  If the input is
        relatively small, you can save space by using a smaller data
        type.  Defaults to unsigned integer.
        """
    )

    def _scalar_type_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetScalarType,
                        self.scalar_type_)

    components_to_process = traits.Array(enter_set=True, auto_set=False, shape=(2,), dtype="int", value=(0, 0), cols=2, desc=\
        r"""
        Set/get the components of the arrays in the two input columns to
        be used during histogram computation.  Defaults to component 0.
        """
    )

    def _components_to_process_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComponentsToProcess,
                        self.components_to_process)

    custom_histogram_extents = traits.Array(enter_set=True, auto_set=False, shape=(4,), dtype="float", value=(0.0, 0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        Set/get a custom domain for histogram computation. 
        use_custom_histogram_extents must be called for these to actually be
        used.
        """
    )

    def _custom_histogram_extents_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCustomHistogramExtents,
                        self.custom_histogram_extents)

    number_of_bins = traits.Array(enter_set=True, auto_set=False, shape=(2,), dtype="int", value=(0, 0), cols=2, desc=\
        r"""
        Set/get the number of bins to be used per dimension (x,y)
        """
    )

    def _number_of_bins_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfBins,
                        self.number_of_bins)

    def _get_row_mask(self):
        return wrap_vtk(self._vtk_obj.GetRowMask())
    def _set_row_mask(self, arg):
        old_val = self._get_row_mask()
        my_arg = deref_array([arg], [['vtkDataArray']])
        self._wrap_call(self._vtk_obj.SetRowMask,
                        my_arg[0])
        self.trait_property_changed('row_mask', old_val, arg)
    row_mask = traits.Property(_get_row_mask, _set_row_mask, desc=\
        r"""
        
        """
    )

    def get_bin_range(self, *args):
        """
        get_bin_range(self, binX:int, binY:int, range:[float, float, float,
            float]) -> int
        C++: int get_bin_range(IdType binX, IdType binY,
            double range[4])
        get_bin_range(self, bin:int, range:[float, float, float, float])
            -> int
        C++: int get_bin_range(IdType bin, double range[4])
        Compute the range of the bin located at position (binX,binY) in
        the 2D histogram.
        """
        ret = self._wrap_call(self._vtk_obj.GetBinRange, *args)
        return ret

    def get_bin_width(self, *args):
        """
        get_bin_width(self, bw:[float, float]) -> None
        C++: void get_bin_width(double bw[2])
        Get the width of all of the bins. Also stored in the spacing ivar
        of the histogram image output.
        """
        ret = self._wrap_call(self._vtk_obj.GetBinWidth, *args)
        return ret

    def _get_histogram_extents(self):
        return self._vtk_obj.GetHistogramExtents()
    histogram_extents = traits.Property(_get_histogram_extents, desc=\
        r"""
        Get the histogram extents currently in use, either computed or
        set by the user.
        """
    )

    def _get_maximum_bin_count(self):
        return self._vtk_obj.GetMaximumBinCount()
    maximum_bin_count = traits.Property(_get_maximum_bin_count, desc=\
        r"""
        Access the count of the histogram bin containing the largest
        number of input rows.
        """
    )

    def _get_output_histogram_image(self):
        return wrap_vtk(self._vtk_obj.GetOutputHistogramImage())
    output_histogram_image = traits.Property(_get_output_histogram_image, desc=\
        r"""
        Gets the data object at the histogram image output port and casts
        it to a ImageData.
        """
    )

    _updateable_traits_ = \
    (('swap_columns', 'GetSwapColumns'), ('use_custom_histogram_extents',
    'GetUseCustomHistogramExtents'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('scalar_type',
    'GetScalarType'), ('components_to_process', 'GetComponentsToProcess'),
    ('custom_histogram_extents', 'GetCustomHistogramExtents'),
    ('number_of_bins', 'GetNumberOfBins'), ('assess_option',
    'GetAssessOption'), ('derive_option', 'GetDeriveOption'),
    ('learn_option', 'GetLearnOption'), ('number_of_primary_tables',
    'GetNumberOfPrimaryTables'), ('test_option', 'GetTestOption'),
    ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'swap_columns', 'use_custom_histogram_extents',
    'scalar_type', 'abort_output', 'assess_option',
    'components_to_process', 'custom_histogram_extents', 'derive_option',
    'learn_option', 'number_of_bins', 'number_of_primary_tables',
    'object_name', 'progress_text', 'test_option'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(ExtractHistogram2D, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit ExtractHistogram2D properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['swap_columns', 'use_custom_histogram_extents'],
            ['scalar_type'], ['abort_output', 'assess_option',
            'components_to_process', 'custom_histogram_extents', 'derive_option',
            'learn_option', 'number_of_bins', 'number_of_primary_tables',
            'object_name', 'test_option']),
            title='Edit ExtractHistogram2D properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit ExtractHistogram2D properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

