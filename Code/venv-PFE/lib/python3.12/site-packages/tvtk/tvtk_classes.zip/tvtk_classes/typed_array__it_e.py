# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.array import Array


class TypedArray_ItE(Array):
    r"""
    TypedArray<unsigned short> - Provides a type-specific interface to
    N-way arrays
    
    Superclass: Array
    
    TypedArray provides an interface for retrieving and updating data
    in an arbitrary-dimension array.  It derives from Array and is
    templated on the type of value stored in the array.
    
    Methods are provided for retrieving and updating array values based
    either on their array coordinates, or on a 1-dimensional integer
    index.  The latter approach can be used to iterate over the values in
    an array in arbitrary order, which is useful when writing filters
    that operate efficiently on sparse arrays and arrays that can have
    any number of dimensions.
    
    Special overloaded methods provide simple access for arrays with one,
    two, or three dimensions.
    
    @sa
    Array, DenseArray, SparseArray
    
    @par Thanks: Developed by Timothy M. Shead (tshead@sandia.gov) at
    Sandia National Laboratories.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkTypedArray_ItE, obj, update, **traits)
    
    def get_value(self, *args):
        """
        get_value(self, i:int) -> int
        C++: virtual const unsigned short &get_value(CoordinateT i)
        get_value(self, i:int, j:int) -> int
        C++: virtual const unsigned short &get_value(CoordinateT i,
            CoordinateT j)
        get_value(self, i:int, j:int, k:int) -> int
        C++: virtual const unsigned short &get_value(CoordinateT i,
            CoordinateT j, CoordinateT k)
        get_value(self, coordinates:ArrayCoordinates) -> int
        C++: virtual const unsigned short &get_value(
            const ArrayCoordinates &coordinates)
        Returns the value stored in the array at the given coordinates.
        Note that the number of dimensions in the supplied coordinates
        must match the number of dimensions in the array.
        """
        my_args = deref_array(args, [['int'], ('int', 'int'), ('int', 'int', 'int'), ['vtkArrayCoordinates']])
        ret = self._wrap_call(self._vtk_obj.GetValue, *my_args)
        return ret

    def set_value(self, *args):
        """
        set_value(self, i:int, value:int) -> None
        C++: virtual void set_value(CoordinateT i,
            const unsigned short &value)
        set_value(self, i:int, j:int, value:int) -> None
        C++: virtual void set_value(CoordinateT i, CoordinateT j,
            const unsigned short &value)
        set_value(self, i:int, j:int, k:int, value:int) -> None
        C++: virtual void set_value(CoordinateT i, CoordinateT j,
            CoordinateT k, const unsigned short &value)
        set_value(self, coordinates:ArrayCoordinates, value:int) -> None
        C++: virtual void set_value(const ArrayCoordinates &coordinates,
             const unsigned short &value)
        Overwrites the value stored in the array at the given
        coordinates. Note that the number of dimensions in the supplied
        coordinates must match the number of dimensions in the array.
        """
        my_args = deref_array(args, [('int', 'int'), ('int', 'int', 'int'), ('int', 'int', 'int', 'int'), ('vtkArrayCoordinates', 'int')])
        ret = self._wrap_call(self._vtk_obj.SetValue, *my_args)
        return ret

    def get_value_n(self, *args):
        """
        get_value_n(self, n:int) -> int
        C++: virtual const unsigned short &get_value_n(SizeT n)
        Returns the n-th value stored in the array, where n is in the
        range [0, get_non_null_size()).  This is useful for efficiently
        visiting every value in the array.  Note that the order in which
        values are visited is undefined, but is guaranteed to match the
        order used by Array::GetCoordinatesN().
        """
        ret = self._wrap_call(self._vtk_obj.GetValueN, *args)
        return ret

    def set_value_n(self, *args):
        """
        set_value_n(self, n:int, value:int) -> None
        C++: virtual void set_value_n(SizeT n, const unsigned short &value)
        Overwrites the n-th value stored in the array, where n is in the
        range [0, get_non_null_size()).  This is useful for efficiently
        visiting every value in the array.  Note that the order in which
        values are visited is undefined, but is guaranteed to match the
        order used by Array::GetCoordinatesN().
        """
        ret = self._wrap_call(self._vtk_obj.SetValueN, *args)
        return ret

    def get_variant_value(self, *args):
        """
        get_variant_value(self, coordinates:ArrayCoordinates)
            -> Variant
        C++: Variant get_variant_value(
            const ArrayCoordinates &coordinates) override;
        get_variant_value(self, i:int) -> Variant
        C++: Variant get_variant_value(CoordinateT i)
        get_variant_value(self, i:int, j:int) -> Variant
        C++: Variant get_variant_value(CoordinateT i, CoordinateT j)
        get_variant_value(self, i:int, j:int, k:int) -> Variant
        C++: Variant get_variant_value(CoordinateT i, CoordinateT j,
            CoordinateT k)"""
        my_args = deref_array(args, [['vtkArrayCoordinates'], ['int'], ('int', 'int'), ('int', 'int', 'int')])
        ret = self._wrap_call(self._vtk_obj.GetVariantValue, *my_args)
        return wrap_vtk(ret)

    def set_variant_value(self, *args):
        """
        set_variant_value(self, coordinates:ArrayCoordinates,
            value:Variant) -> None
        C++: void set_variant_value(const ArrayCoordinates &coordinates,
            const Variant &value) override;
        set_variant_value(self, i:int, value:Variant) -> None
        C++: void set_variant_value(CoordinateT i, const Variant &value)
        set_variant_value(self, i:int, j:int, value:Variant) -> None
        C++: void set_variant_value(CoordinateT i, CoordinateT j,
            const Variant &value)
        set_variant_value(self, i:int, j:int, k:int, value:Variant)
            -> None
        C++: void set_variant_value(CoordinateT i, CoordinateT j,
            CoordinateT k, const Variant &value)"""
        my_args = deref_array(args, [('vtkArrayCoordinates', 'vtkVariant'), ('int', 'vtkVariant'), ('int', 'int', 'vtkVariant'), ('int', 'int', 'int', 'vtkVariant')])
        ret = self._wrap_call(self._vtk_obj.SetVariantValue, *my_args)
        return ret

    def get_variant_value_n(self, *args):
        """
        get_variant_value_n(self, n:int) -> Variant
        
        Returns the n-th value stored in the array, where n is in the
        range [0, get_non_null_size()).  This is useful for efficiently
        visiting every value in the array.  Note that the order in which
        values are visited is undefined, but is guaranteed to match the
        order used by Array::GetCoordinatesN().
        """
        ret = self._wrap_call(self._vtk_obj.GetVariantValueN, *args)
        return wrap_vtk(ret)

    def set_variant_value_n(self, *args):
        """
        set_variant_value_n(self, n:int, value:Variant) -> None
        C++: void set_variant_value_n(SizeT n, const Variant &value)
            override;
        Overwrites the n-th value stored in the array, where n is in the
        range [0, get_non_null_size()).  This is useful for efficiently
        visiting every value in the array.  Note that the order in which
        values are visited is undefined, but is guaranteed to match the
        order used by Array::GetCoordinatesN().
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetVariantValueN, *my_args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('name', 'GetName'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'name', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(TypedArray_ItE, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit TypedArray_ItE properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['name', 'object_name']),
            title='Edit TypedArray_ItE properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit TypedArray_ItE properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

