# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.cell_grid_query import CellGridQuery


class OpenGLCellGridRenderRequest(CellGridQuery):
    r"""
    OpenGLCellGridRenderRequest - State used by
    OpenGLCellGridMapper during rendering.
    
    Superclass: CellGridQuery
    
    This is a CellGridQuery subclass that mappers can use to draw
    cells into a renderer using an actor and, subsequently, to release
    resources.
    
    Note that this request has two modes: it will either instruct
    responders to draw cells (is_releasing_resources == false) or instruct
    responders to release open_gl objects for a particular window (when
    is_releasing_resources == true). Responders must call
    get_is_releasing_resources() and only perform one task or the other,
    depending on the returned value.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkOpenGLCellGridRenderRequest, obj, update, **traits)
    
    def _get_actor(self):
        return wrap_vtk(self._vtk_obj.GetActor())
    def _set_actor(self, arg):
        old_val = self._get_actor()
        self._wrap_call(self._vtk_obj.SetActor,
                        deref_vtk(arg))
        self.trait_property_changed('actor', old_val, arg)
    actor = traits.Property(_get_actor, _set_actor, desc=\
        r"""
        
        """
    )

    is_releasing_resources = traits.Bool(False, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _is_releasing_resources_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetIsReleasingResources,
                        self.is_releasing_resources)

    def _get_mapper(self):
        return wrap_vtk(self._vtk_obj.GetMapper())
    def _set_mapper(self, arg):
        old_val = self._get_mapper()
        self._wrap_call(self._vtk_obj.SetMapper,
                        deref_vtk(arg))
        self.trait_property_changed('mapper', old_val, arg)
    mapper = traits.Property(_get_mapper, _set_mapper, desc=\
        r"""
        
        """
    )

    def _get_renderer(self):
        return wrap_vtk(self._vtk_obj.GetRenderer())
    def _set_renderer(self, arg):
        old_val = self._get_renderer()
        self._wrap_call(self._vtk_obj.SetRenderer,
                        deref_vtk(arg))
        self.trait_property_changed('renderer', old_val, arg)
    renderer = traits.Property(_get_renderer, _set_renderer, desc=\
        r"""
        
        """
    )

    shapes_to_draw = traits.String('\x0f', enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _shapes_to_draw_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetShapesToDraw,
                        self.shapes_to_draw)

    def _get_window(self):
        return wrap_vtk(self._vtk_obj.GetWindow())
    def _set_window(self, arg):
        old_val = self._get_window()
        self._wrap_call(self._vtk_obj.SetWindow,
                        deref_vtk(arg))
        self.trait_property_changed('window', old_val, arg)
    window = traits.Property(_get_window, _set_window, desc=\
        r"""
        
        """
    )

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('is_releasing_resources',
    'GetIsReleasingResources'), ('shapes_to_draw', 'GetShapesToDraw'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'is_releasing_resources',
    'object_name', 'shapes_to_draw'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(OpenGLCellGridRenderRequest, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit OpenGLCellGridRenderRequest properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['is_releasing_resources', 'object_name',
            'shapes_to_draw']),
            title='Edit OpenGLCellGridRenderRequest properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit OpenGLCellGridRenderRequest properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

