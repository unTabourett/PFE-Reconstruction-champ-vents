# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.unstructured_grid_algorithm import UnstructuredGridAlgorithm


class Threshold(UnstructuredGridAlgorithm):
    r"""
    Threshold - extracts cells where scalar value in cell satisfies
    threshold criterion
    
    Superclass: UnstructuredGridAlgorithm
    
    Threshold is a filter that extracts cells from any dataset type
    that satisfy a threshold criterion. A cell satisfies the criterion if
    the scalar value of (every or any) point satisfies the criterion. The
    criterion can take three forms: 1) greater than a particular value;
    2) less than a particular value; or 3) between two values. The output
    of this filter is an unstructured grid.
    
    Note that scalar values are available from the point and cell
    attribute data.  By default, point data is used to obtain scalars,
    but you can control this behavior. See the attribute_mode ivar below.
    
    By default only the first scalar value is used in the decision. Use
    the component_mode and selected_component ivars to control this
    behavior.
    
    @warning
    This class is templated. It may run slower than serial execution if
    the code is not optimized during compilation. Build in Release or
    release_with_debug_info.
    
    @warning
    This class has been threaded with SMPTools. Using TBB or other
    non-sequential type (set in the CMake variable
    VTK_SMP_IMPLEMENTATION_TYPE) may improve performance significantly.
    
    @sa
    ThresholdPoints ThresholdTextureCoords
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkThreshold, obj, update, **traits)
    
    all_scalars = tvtk_base.true_bool_trait(desc=\
        r"""
        If using scalars from point data, all scalars for all points in a
        cell must satisfy the threshold criterion if all_scalars is set.
        Otherwise, just a single scalar value satisfying the threshold
        criterion enables will extract the cell.
        """
    )

    def _all_scalars_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAllScalars,
                        self.all_scalars_)

    invert = tvtk_base.false_bool_trait(desc=\
        r"""
        Invert the threshold results. That is, cells that would have been
        in the output with this option off are excluded, while cells that
        would have been excluded from the output are included.
        """
    )

    def _invert_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetInvert,
                        self.invert_)

    use_continuous_cell_range = tvtk_base.false_bool_trait(desc=\
        r"""
        If this is on (default is off), we will use the continuous
        interval [minimum cell scalar, maximum cell scalar] to intersect
        the threshold bound , rather than the set of discrete scalar
        values from the vertices
        *WARNING*: For higher order cells, the scalar range of the cell
            is not the same as the vertex scalar interval used here, so
            the result will not be accurate.
        """
    )

    def _use_continuous_cell_range_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUseContinuousCellRange,
                        self.use_continuous_cell_range_)

    attribute_mode = tvtk_base.RevPrefixMap({'default': 0, 'use_cell_data': 2, 'use_point_data': 1}, -1, default_value='default', desc=\
        r"""
        Control how the filter works with scalar point data and cell
        attribute data.  By default (attribute_mode_to_default), the filter
        will use point data, and if no point data is available, then cell
        data is used. Alternatively you can explicitly set the filter to
        use point data (attribute_mode_to_use_point_data) or cell data
        (attribute_mode_to_use_cell_data).
        """
    )

    def _attribute_mode_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAttributeMode,
                        self.attribute_mode_)

    component_mode = tvtk_base.RevPrefixMap({'use_selected': 0, 'use_all': 1, 'use_any': 2}, default_value='use_selected', desc=\
        r"""
        Control how the decision of in / out is made with multi-component
        data. The choices are to use the selected component (specified in
        the selected_component ivar), or to look at all components. When
        looking at all components, the evaluation can pass if all the
        components satisfy the rule (use_all) or if any satisfy is
        (use_any). The default value is use_selected.
        """
    )

    def _component_mode_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComponentMode,
                        self.component_mode_)

    def get_points_data_type(self):
        """
        get_points_data_type(self) -> int
        C++: int get_points_data_type()"""
        ret = self._vtk_obj.GetPointsDataType()
        return ret
        

    def set_points_data_type_to_float(self):
        """
        set_points_data_type_to_float(self) -> None
        C++: void set_points_data_type_to_float()"""
        self._vtk_obj.SetPointsDataTypeToFloat()

    lower_threshold = traits.Float(-inf, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _lower_threshold_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLowerThreshold,
                        self.lower_threshold)

    output_points_precision = traits.Int(2, enter_set=True, auto_set=False, desc=\
        r"""
        Set/get the desired precision for the output types. See the
        documentation for the Algorithm::DesiredOutputPrecision enum
        for an explanation of the available precision settings.
        """
    )

    def _output_points_precision_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOutputPointsPrecision,
                        self.output_points_precision)

    selected_component = traits.Trait(0, traits.Range(0, 2147483647, enter_set=True, auto_set=False), desc=\
        r"""
        When the component mode is use_selected, this ivar indicated the
        selected component. The default value is 0.
        """
    )

    def _selected_component_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSelectedComponent,
                        self.selected_component)

    threshold_function = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Get/Set the threshold method, defining which threshold bounds to
        use. The default method is Threshold::Between.
        """
    )

    def _threshold_function_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetThresholdFunction,
                        self.threshold_function)

    upper_threshold = traits.Float(inf, enter_set=True, auto_set=False, desc=\
        r"""
        Set/get the upper and lower thresholds. The default values are
        set to +infinity and -infinity, respectively.
        """
    )

    def _upper_threshold_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUpperThreshold,
                        self.upper_threshold)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)
        get_input(self) -> DataObject
        C++: DataObject *get_input()"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    def between(self, *args):
        """
        between(self, s:float) -> int
        C++: int between(double s)"""
        ret = self._wrap_call(self._vtk_obj.Between, *args)
        return ret

    def lower(self, *args):
        """
        lower(self, s:float) -> int
        C++: int lower(double s)
        Methods used for thresholding. Threshold::Lower returns true
        if s is lower than the lower threshold, Threshold::Upper
        returns true if s is larger than the upper threshold, and
        Threshold::Between returns true if s is between the lower and
        upper thresholds.
        
        @warning These methods use threshold values that can be set with
        Threshold::SetLowerThreshold and
        Threshold::SetUpperThreshold. The threshold method can be set
        using Threshold::SetThresholdFunction.
        
        ote They are not protected members for inheritance purposes. The
        addresses of those methods are stored in one of this class
        attributes to figure out which version of the threshold to apply,
        which are inaccessible if protected.
        """
        ret = self._wrap_call(self._vtk_obj.Lower, *args)
        return ret

    def upper(self, *args):
        """
        upper(self, s:float) -> int
        C++: int upper(double s)"""
        ret = self._wrap_call(self._vtk_obj.Upper, *args)
        return ret

    _updateable_traits_ = \
    (('all_scalars', 'GetAllScalars'), ('invert', 'GetInvert'),
    ('use_continuous_cell_range', 'GetUseContinuousCellRange'),
    ('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('attribute_mode', 'GetAttributeMode'), ('component_mode',
    'GetComponentMode'), ('lower_threshold', 'GetLowerThreshold'),
    ('output_points_precision', 'GetOutputPointsPrecision'),
    ('selected_component', 'GetSelectedComponent'), ('threshold_function',
    'GetThresholdFunction'), ('upper_threshold', 'GetUpperThreshold'),
    ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'all_scalars', 'debug', 'global_warning_display',
    'invert', 'release_data_flag', 'use_continuous_cell_range',
    'attribute_mode', 'component_mode', 'abort_output', 'lower_threshold',
    'object_name', 'output_points_precision', 'progress_text',
    'selected_component', 'threshold_function', 'upper_threshold'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Threshold, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Threshold properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['all_scalars', 'invert', 'use_continuous_cell_range'],
            ['attribute_mode', 'component_mode'], ['abort_output',
            'lower_threshold', 'object_name', 'output_points_precision',
            'selected_component', 'threshold_function', 'upper_threshold']),
            title='Edit Threshold properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Threshold properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

