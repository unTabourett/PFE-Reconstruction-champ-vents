# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class XMLUtilities(Object):
    r"""
    XMLUtilities - XML utilities.
    
    Superclass: Object
    
    XMLUtilities provides XML-related convenience functions.
    @sa
    XMLDataElement
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkXMLUtilities, obj, update, **traits)
    
    def factor_elements(self, *args):
        """
        factor_elements(tree:XMLDataElement) -> None
        C++: static void factor_elements(XMLDataElement *tree)
        Factor and unfactor a tree. This operation looks for duplicate
        elements in the tree, and replace them with references to a pool
        of elements. Unfactoring a non-factored element is harmless.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.FactorElements, *my_args)
        return ret

    def read_element_from_file(self, *args):
        """
        read_element_from_file(filename:str, encoding:int=...)
            -> XMLDataElement
        C++: static XMLDataElement *read_element_from_file(
            const char *filename, int encoding=VTK_ENCODING_NONE)"""
        ret = self._wrap_call(self._vtk_obj.ReadElementFromFile, *args)
        return wrap_vtk(ret)

    def read_element_from_string(self, *args):
        """
        read_element_from_string(str:str, encoding:int=...)
            -> XMLDataElement
        C++: static XMLDataElement *read_element_from_string(
            const char *str, int encoding=VTK_ENCODING_NONE)"""
        ret = self._wrap_call(self._vtk_obj.ReadElementFromString, *args)
        return wrap_vtk(ret)

    def un_factor_elements(self, *args):
        """
        un_factor_elements(tree:XMLDataElement) -> None
        C++: static void un_factor_elements(XMLDataElement *tree)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.UnFactorElements, *my_args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(XMLUtilities, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit XMLUtilities properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit XMLUtilities properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit XMLUtilities properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

