# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.actor import Actor


class Avatar(Actor):
    r"""
    Avatar - Renders head and hands for a user in VR
    
    Superclass: Actor
    
    Set position and orientation for the head and two hands, shows an
    observer where the avatar is looking and pointing.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkAvatar, obj, update, **traits)
    
    show_hands_only = tvtk_base.false_bool_trait(desc=\
        r"""
        Show just the hands. Default false.
        """
    )

    def _show_hands_only_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetShowHandsOnly,
                        self.show_hands_only_)

    use_left_hand = tvtk_base.true_bool_trait(desc=\
        r"""
        Normally, hand position/orientation is set explicitly. If set to
        false, hand and arm will follow the torso in a neutral position.
        """
    )

    def _use_left_hand_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUseLeftHand,
                        self.use_left_hand_)

    use_right_hand = tvtk_base.true_bool_trait(desc=\
        r"""
        
        """
    )

    def _use_right_hand_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUseRightHand,
                        self.use_right_hand_)

    head_orientation = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        
        """
    )

    def _head_orientation_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetHeadOrientation,
                        self.head_orientation)

    head_position = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        
        """
    )

    def _head_position_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetHeadPosition,
                        self.head_position)

    left_hand_orientation = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        
        """
    )

    def _left_hand_orientation_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLeftHandOrientation,
                        self.left_hand_orientation)

    left_hand_position = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        
        """
    )

    def _left_hand_position_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLeftHandPosition,
                        self.left_hand_position)

    right_hand_orientation = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        
        """
    )

    def _right_hand_orientation_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRightHandOrientation,
                        self.right_hand_orientation)

    right_hand_position = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        
        """
    )

    def _right_hand_position_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRightHandPosition,
                        self.right_hand_position)

    up_vector = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(0.0, 1.0, 0.0), cols=3, desc=\
        r"""
        
        """
    )

    def _up_vector_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUpVector,
                        self.up_vector)

    _updateable_traits_ = \
    (('show_hands_only', 'GetShowHandsOnly'), ('use_left_hand',
    'GetUseLeftHand'), ('use_right_hand', 'GetUseRightHand'),
    ('force_opaque', 'GetForceOpaque'), ('force_translucent',
    'GetForceTranslucent'), ('dragable', 'GetDragable'), ('pickable',
    'GetPickable'), ('use_bounds', 'GetUseBounds'), ('visibility',
    'GetVisibility'), ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('coordinate_system',
    'GetCoordinateSystem'), ('head_orientation', 'GetHeadOrientation'),
    ('head_position', 'GetHeadPosition'), ('left_hand_orientation',
    'GetLeftHandOrientation'), ('left_hand_position',
    'GetLeftHandPosition'), ('right_hand_orientation',
    'GetRightHandOrientation'), ('right_hand_position',
    'GetRightHandPosition'), ('up_vector', 'GetUpVector'),
    ('coordinate_system_device', 'GetCoordinateSystemDevice'),
    ('orientation', 'GetOrientation'), ('origin', 'GetOrigin'),
    ('position', 'GetPosition'), ('scale', 'GetScale'),
    ('estimated_render_time', 'GetEstimatedRenderTime'),
    ('render_time_multiplier', 'GetRenderTimeMultiplier'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'dragable', 'force_opaque', 'force_translucent',
    'global_warning_display', 'pickable', 'show_hands_only', 'use_bounds',
    'use_left_hand', 'use_right_hand', 'visibility', 'coordinate_system',
    'coordinate_system_device', 'estimated_render_time',
    'head_orientation', 'head_position', 'left_hand_orientation',
    'left_hand_position', 'object_name', 'orientation', 'origin',
    'position', 'render_time_multiplier', 'right_hand_orientation',
    'right_hand_position', 'scale', 'up_vector'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Avatar, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Avatar properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['force_opaque', 'force_translucent', 'show_hands_only',
            'use_bounds', 'use_left_hand', 'use_right_hand', 'visibility'],
            ['coordinate_system'], ['coordinate_system_device',
            'estimated_render_time', 'head_orientation', 'head_position',
            'left_hand_orientation', 'left_hand_position', 'object_name',
            'orientation', 'origin', 'position', 'render_time_multiplier',
            'right_hand_orientation', 'right_hand_position', 'scale',
            'up_vector']),
            title='Edit Avatar properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Avatar properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

