# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.data_set_algorithm import DataSetAlgorithm


class AttributeSmoothingFilter(DataSetAlgorithm):
    r"""
    AttributeSmoothingFilter - smooth mesh point attribute data using
    distance weighted Laplacian kernel
    
    Superclass: DataSetAlgorithm
    
    AttributeSmoothingFilter is a filter that smooths point attribute
    data using a Laplacian smoothing approach. The effect is to "relax"
    or "smooth" the attributes, reducing high frequency information. Note
    that this filter operates on all dataset types.
    
    A central concept of this filter is the point smoothing stencil. A
    smoothing stencil for a point p(i) is the list of points p(j) which
    connect to p(i) via an edge. To smooth the attributes of point p(i),
    p(i)'s attribute data a(i) are iteratively averaged using the
    distance weighted average of the attributes of a(j) (the weights w[j]
    sum to 1). This averaging process is repeated until the maximum
    number of iterations is reached.
    
    The relaxation factor R is also important as the smoothing process
    proceeds in an iterative fashion. The a(i+1) attributes are
    determined from the a(i) attributes as follows: ``` a(i+1) =
    (1-R)*a(i) + R*sum(w(j)*a(j)) ```
    
    Convergence occurs faster for larger relaxation factors. Typically a
    small number of iterations is required for large relaxation factors,
    and in cases where only points adjacent to the boundary are being
    smoothed, a single iteration with R=1 may be adequate (i.e., just a
    distance weighted average is computed).
    
    To control what regions in the dataset have their attributes
    smoothed, it is possible to specify which points (and their
    attributes) are allowed to be smoothed (and therefore also those that
    are constrained). Typically point data attributes may be constrained
    on the boundary, or only point attributes directly connected (i.e.,
    adjacent) to the boundary may be allowed to change (this supports
    smooth transition of attributes from the boundary into the interior
    of the mesh). Note that the meaning of a boundary point (versus
    interior point) changes depending on the input dataset type. For
    PolyData, boundary *edges* are used to identify boundary points;
    for all other dataset types, points used by a boundary
    *face* are considered boundary points. It is also possible to
        explicitly specify which points are smoothed, and those that are
        constrained, by specifying a smooth mask associated with each
        input point.
    
    To control which point data attributes are to be smoothed, specify in
    excluded_arrays which arrays should not be smoothed--these data arrays
    are simply passed through to the output of the filter.
    
    @warning
    Certain data attributes cannot be correctly interpolated using this
    filter.  For example, surface normals are expected to be |n|=1; after
    attribute smoothing this constraint is likely to be violated. Other
    vectors and tensors may suffer from similar issues. In such a
    situation, specify excluded_arrays which will not be smoothed (and
    simply passed through to the output of the filter).
    
    @warning
    Currently the distance weighting function is based on averaging, 1/r,
    or 1/(r**2) weights (user selectable), where r is the distance
    between the point to be smoothed and an edge connected neighbor
    (defined by the smoothing stencil). The weights are normalized so
    that sum(w(i))==1. When smoothing based on averaging, the weights are
    simply 1/n, where n is the number of connected points in the stencil.
    
    @warning
    The smoothing process reduces high frequency information in the data
    attributes. With excessive smoothing (large numbers of iterations,
    and/or a large relaxation factor) important details may be lost, and
    the attributes will move towards an "average" value.
    
    @warning
    While this filter will process any dataset type, if the input data is
    a 3D image volume, it's likely much faster to use an image-based
    algorithm to perform data smoothing.
    
    @warning
    To determine boundary points in PolyData, edges used by only one
    cell are considered boundary (and hence the associated points
    defining the edge). To determine boundary points for all other
    dataset types, a MarkBoundaryFilter is used to extract the
    boundary faces - this can be time consuming for large data.
    
    @sa
    ConstrainedSmoothingFilter WindowedSincPolyDataFilter
    SmoothPolyDataFilter ExtractEdges MarkBoundaryFilter
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkAttributeSmoothingFilter, obj, update, **traits)
    
    smoothing_strategy = tvtk_base.RevPrefixMap({'all_points': 0, 'adjacent_to_boundary': 2, 'all_but_boundary': 1, 'smoothing_mask': 3}, default_value='all_points', desc=\
        r"""
        Indicate how to constrain smoothing of the attribute data. By
        default, all point data attributes are smoothed (ALL_POINTS). If
        ALL_BUT_BOUNDARY is selected, then all point attribute data
        except those on the boundary of the mesh are smoothed.  If
        ADJACENT_TO_BOUNDARY is selected, then only point data connected
        to a boundary point are smoothed, but boundary and interior
        points are not. (ALL_BUT_BOUNDARY and ADJACENT_TO_BOUNDARY are
        useful for transitioning from fixed boundary conditions to
        interior data.) If desired, it is possible to explicitly specify
        a smoothing mask controlling which points are smoothed and not
        smoothed. The default constraint strategy is ALL_POINTS.
        """
    )

    def _smoothing_strategy_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSmoothingStrategy,
                        self.smoothing_strategy_)

    weights_type = tvtk_base.RevPrefixMap({'distance2': 2, 'average': 0, 'distance': 1}, default_value='distance2', desc=\
        r"""
        Indicate how to compute weights, using 1) a simple average of all
        connected points in the stencil; 2) a distance-weighted (i.e.,
        1/r) approach; or 3) distance**2-weighted (i.e., 1/(r**2)
        interpolation weights). The default constraint strategy is
        distance**2-weighted (i.e., DISTANCE2).
        """
    )

    def _weights_type_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetWeightsType,
                        self.weights_type_)

    number_of_iterations = traits.Trait(5, traits.Range(0, 2147483647, enter_set=True, auto_set=False), desc=\
        r"""
        Specify the maximum number of iterations for smoothing.  The
        default value is 5.
        """
    )

    def _number_of_iterations_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfIterations,
                        self.number_of_iterations)

    relaxation_factor = traits.Trait(0.1, traits.Range(0.0, 1.0, enter_set=True, auto_set=False), desc=\
        r"""
        Specify the relaxation factor for smoothing. As in all iterative
        methods, the stability of the process is sensitive to this
        parameter. In general, small relaxation factors and large numbers
        of iterations are more stable than larger relaxation factors and
        smaller numbers of iterations. The default value is 0.10.
        """
    )

    def _relaxation_factor_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRelaxationFactor,
                        self.relaxation_factor)

    def _get_smoothing_mask(self):
        return wrap_vtk(self._vtk_obj.GetSmoothingMask())
    def _set_smoothing_mask(self, arg):
        old_val = self._get_smoothing_mask()
        my_arg = deref_array([arg], [['vtkUnsignedCharArray']])
        self._wrap_call(self._vtk_obj.SetSmoothingMask,
                        my_arg[0])
        self.trait_property_changed('smoothing_mask', old_val, arg)
    smoothing_mask = traits.Property(_get_smoothing_mask, _set_smoothing_mask, desc=\
        r"""
        
        """
    )

    def get_excluded_array(self, *args):
        """
        get_excluded_array(self, i:int) -> str
        C++: const char *get_excluded_array(int i)
        Return the name of the ith excluded array.
        """
        ret = self._wrap_call(self._vtk_obj.GetExcludedArray, *args)
        return ret

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input data object. This method is not recommended for
        use, but lots of old style filters use it.
        """
    )

    def _get_number_of_excluded_arrays(self):
        return self._vtk_obj.GetNumberOfExcludedArrays()
    number_of_excluded_arrays = traits.Property(_get_number_of_excluded_arrays, desc=\
        r"""
        Return the number of excluded arrays.
        """
    )

    def add_excluded_array(self, *args):
        """
        add_excluded_array(self, excludedArray:str) -> None
        C++: void add_excluded_array(const std::string &excludedArray)
        Adds an array to the list of arrays which are to be excluded from
        the interpolation process. Any specified arrays are simply passed
        through to the filter output.
        """
        ret = self._wrap_call(self._vtk_obj.AddExcludedArray, *args)
        return ret

    def clear_excluded_arrays(self):
        """
        clear_excluded_arrays(self) -> None
        C++: void clear_excluded_arrays()
        Clears the contents of excluded array list.
        """
        ret = self._vtk_obj.ClearExcludedArrays()
        return ret
        

    _updateable_traits_ = \
    (('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('smoothing_strategy', 'GetSmoothingStrategy'), ('weights_type',
    'GetWeightsType'), ('number_of_iterations', 'GetNumberOfIterations'),
    ('relaxation_factor', 'GetRelaxationFactor'), ('abort_output',
    'GetAbortOutput'), ('progress_text', 'GetProgressText'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'smoothing_strategy', 'weights_type',
    'abort_output', 'number_of_iterations', 'object_name',
    'progress_text', 'relaxation_factor'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(AttributeSmoothingFilter, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit AttributeSmoothingFilter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], ['smoothing_strategy', 'weights_type'], ['abort_output',
            'number_of_iterations', 'object_name', 'relaxation_factor']),
            title='Edit AttributeSmoothingFilter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit AttributeSmoothingFilter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

