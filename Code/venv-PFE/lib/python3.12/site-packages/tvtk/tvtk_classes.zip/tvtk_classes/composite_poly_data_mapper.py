# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.poly_data_mapper import PolyDataMapper


class CompositePolyDataMapper(PolyDataMapper):
    r"""
    CompositePolyDataMapper - a class that renders hierarchical
    polygonal data
    
    Superclass: PolyDataMapper
    
    This class uses a set of PolyDataMappers to render input data
    which may be hierarchical. The input to this mapper may be either
    PolyData or a CompositeDataSet built from polydata. If
    something other than PolyData is encountered, an error message
    will be produced.
    @sa
    PolyDataMapper
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCompositePolyDataMapper, obj, update, **traits)
    
    color_missing_arrays_with_nan_color = tvtk_base.false_bool_trait(desc=\
        r"""
        If the current 'color by' array is missing on some datasets,
        color these dataset by the lookup_table's NaN color, if the lookup
        table supports it. Default is false.
        """
    )

    def _color_missing_arrays_with_nan_color_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetColorMissingArraysWithNanColor,
                        self.color_missing_arrays_with_nan_color_)

    def get_block_array_access_mode(self, *args):
        """
        get_block_array_access_mode(self, index:int) -> int
        C++: int get_block_array_access_mode(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.GetBlockArrayAccessMode, *args)
        return ret

    def set_block_array_access_mode(self, *args):
        """
        set_block_array_access_mode(self, index:int, value:int) -> None
        C++: void set_block_array_access_mode(unsigned int index, int value)
        @see Mapper::SetArrayAccessMode
        """
        ret = self._wrap_call(self._vtk_obj.SetBlockArrayAccessMode, *args)
        return ret

    def get_block_array_component(self, *args):
        """
        get_block_array_component(self, index:int) -> int
        C++: int get_block_array_component(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.GetBlockArrayComponent, *args)
        return ret

    def set_block_array_component(self, *args):
        """
        set_block_array_component(self, index:int, value:int) -> None
        C++: void set_block_array_component(unsigned int index, int value)
        @see Mapper::SetArrayComponent
        """
        ret = self._wrap_call(self._vtk_obj.SetBlockArrayComponent, *args)
        return ret

    def get_block_array_id(self, *args):
        """
        get_block_array_id(self, index:int) -> int
        C++: int get_block_array_id(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.GetBlockArrayId, *args)
        return ret

    def set_block_array_id(self, *args):
        """
        set_block_array_id(self, index:int, value:int) -> None
        C++: void set_block_array_id(unsigned int index, int value)
        @see Mapper::SetArrayId
        """
        ret = self._wrap_call(self._vtk_obj.SetBlockArrayId, *args)
        return ret

    def get_block_array_name(self, *args):
        """
        get_block_array_name(self, index:int) -> str
        C++: std::string get_block_array_name(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.GetBlockArrayName, *args)
        return ret

    def set_block_array_name(self, *args):
        """
        set_block_array_name(self, index:int, value:str) -> None
        C++: void set_block_array_name(unsigned int index,
            const std::string &value)
        @see Mapper::SetArrayName
        """
        ret = self._wrap_call(self._vtk_obj.SetBlockArrayName, *args)
        return ret

    def get_block_color(self, *args):
        """
        get_block_color(self, index:int) -> Pointer
        C++: double *get_block_color(unsigned int index)
        get_block_color(self, index:int, color:[float, float, float])
            -> None
        C++: void get_block_color(unsigned int index, double color[3])"""
        ret = self._wrap_call(self._vtk_obj.GetBlockColor, *args)
        return ret

    def set_block_color(self, *args):
        """
        set_block_color(self, index:int, color:(float, float, float))
            -> None
        C++: void set_block_color(unsigned int index, const double color[3])
        set_block_color(self, index:int, r:float, g:float, b:float) -> None
        C++: void set_block_color(unsigned int index, double r, double g,
            double b)
        Set/get the color for a block given its flat index.
        """
        ret = self._wrap_call(self._vtk_obj.SetBlockColor, *args)
        return ret

    def get_block_field_data_tuple_id(self, *args):
        """
        get_block_field_data_tuple_id(self, index:int) -> int
        C++: IdType get_block_field_data_tuple_id(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.GetBlockFieldDataTupleId, *args)
        return ret

    def set_block_field_data_tuple_id(self, *args):
        """
        set_block_field_data_tuple_id(self, index:int, value:int) -> None
        C++: void set_block_field_data_tuple_id(unsigned int index,
            IdType value)
        @see Mapper::SetFieldDataTupleId
        """
        ret = self._wrap_call(self._vtk_obj.SetBlockFieldDataTupleId, *args)
        return ret

    def get_block_opacity(self, *args):
        """
        get_block_opacity(self, index:int) -> float
        C++: double get_block_opacity(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.GetBlockOpacity, *args)
        return ret

    def set_block_opacity(self, *args):
        """
        set_block_opacity(self, index:int, opacity:float) -> None
        C++: void set_block_opacity(unsigned int index, double opacity)
        Set/get the opacity for a block given its flat index.
        """
        ret = self._wrap_call(self._vtk_obj.SetBlockOpacity, *args)
        return ret

    def get_block_scalar_mode(self, *args):
        """
        get_block_scalar_mode(self, index:int) -> int
        C++: int get_block_scalar_mode(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.GetBlockScalarMode, *args)
        return ret

    def set_block_scalar_mode(self, *args):
        """
        set_block_scalar_mode(self, index:int, value:int) -> None
        C++: void set_block_scalar_mode(unsigned int index, int value)
        @see Mapper::SetScalarMode
        """
        ret = self._wrap_call(self._vtk_obj.SetBlockScalarMode, *args)
        return ret

    def get_block_visibility(self, *args):
        """
        get_block_visibility(self, index:int) -> bool
        C++: bool get_block_visibility(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.GetBlockVisibility, *args)
        return ret

    def set_block_visibility(self, *args):
        """
        set_block_visibility(self, index:int, visible:bool) -> None
        C++: void set_block_visibility(unsigned int index, bool visible)
        Set/get the visibility for a block given its flat index.
        """
        ret = self._wrap_call(self._vtk_obj.SetBlockVisibility, *args)
        return ret

    cell_id_array_name = traits.Trait(None, None, traits.String(enter_set=True, auto_set=False), desc=\
        r"""
        
        """
    )

    def _cell_id_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCellIdArrayName,
                        self.cell_id_array_name)

    def _get_composite_data_display_attributes(self):
        return wrap_vtk(self._vtk_obj.GetCompositeDataDisplayAttributes())
    def _set_composite_data_display_attributes(self, arg):
        old_val = self._get_composite_data_display_attributes()
        self._wrap_call(self._vtk_obj.SetCompositeDataDisplayAttributes,
                        arg)
        self.trait_property_changed('composite_data_display_attributes', old_val, arg)
    composite_data_display_attributes = traits.Property(_get_composite_data_display_attributes, _set_composite_data_display_attributes, desc=\
        r"""
        
        """
    )

    composite_id_array_name = traits.Trait(None, None, traits.String(enter_set=True, auto_set=False), desc=\
        r"""
        Generally, this class can render the composite id when iterating
        over composite datasets. However in some cases (as in AMR), the
        rendered structure may not correspond to the input data, in which
        case we need to provide a cell array that can be used to render
        in the composite id in selection passes. Set to NULL (default) to
        not override the composite id color set by CompositePainter if
        any. The array *MUST* be a cell array and of type
        UnsignedIntArray.
        """
    )

    def _composite_id_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCompositeIdArrayName,
                        self.composite_id_array_name)

    point_id_array_name = traits.Trait(None, None, traits.String(enter_set=True, auto_set=False), desc=\
        r"""
        By default, this class uses the dataset's point and cell ids
        during rendering. However, one can override those by specifying
        cell and point data arrays to use instead. Currently, only
        IdType array is supported. Set to NULL string (default) to use
        the point ids instead.
        """
    )

    def _point_id_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPointIdArrayName,
                        self.point_id_array_name)

    process_id_array_name = traits.Trait(None, None, traits.String(enter_set=True, auto_set=False), desc=\
        r"""
        If this class should override the process id using a data-array,
        set this variable to the name of the array to use. It must be a
        point-array.
        """
    )

    def _process_id_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetProcessIdArrayName,
                        self.process_id_array_name)

    vbo_shift_scale_method = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        A convenience method for enabling/disabling  the VBO's
        shift+scale transform.
        """
    )

    def _vbo_shift_scale_method_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetVBOShiftScaleMethod,
                        self.vbo_shift_scale_method)

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input as a DataSet.  This method is overridden in the
        specialized mapper classes to return more specific data types.
        """
    )

    def remove_block_array_access_mode(self, *args):
        """
        remove_block_array_access_mode(self, index:int) -> None
        C++: void remove_block_array_access_mode(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.RemoveBlockArrayAccessMode, *args)
        return ret

    def remove_block_array_access_modes(self):
        """
        remove_block_array_access_modes(self) -> None
        C++: void remove_block_array_access_modes()"""
        ret = self._vtk_obj.RemoveBlockArrayAccessModes()
        return ret
        

    def remove_block_array_component(self, *args):
        """
        remove_block_array_component(self, index:int) -> None
        C++: void remove_block_array_component(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.RemoveBlockArrayComponent, *args)
        return ret

    def remove_block_array_components(self):
        """
        remove_block_array_components(self) -> None
        C++: void remove_block_array_components()"""
        ret = self._vtk_obj.RemoveBlockArrayComponents()
        return ret
        

    def remove_block_array_id(self, *args):
        """
        remove_block_array_id(self, index:int) -> None
        C++: void remove_block_array_id(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.RemoveBlockArrayId, *args)
        return ret

    def remove_block_array_ids(self):
        """
        remove_block_array_ids(self) -> None
        C++: void remove_block_array_ids()"""
        ret = self._vtk_obj.RemoveBlockArrayIds()
        return ret
        

    def remove_block_array_name(self, *args):
        """
        remove_block_array_name(self, index:int) -> None
        C++: void remove_block_array_name(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.RemoveBlockArrayName, *args)
        return ret

    def remove_block_array_names(self):
        """
        remove_block_array_names(self) -> None
        C++: void remove_block_array_names()"""
        ret = self._vtk_obj.RemoveBlockArrayNames()
        return ret
        

    def remove_block_color(self, *args):
        """
        remove_block_color(self, index:int) -> None
        C++: void remove_block_color(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.RemoveBlockColor, *args)
        return ret

    def remove_block_colors(self):
        """
        remove_block_colors(self) -> None
        C++: void remove_block_colors()"""
        ret = self._vtk_obj.RemoveBlockColors()
        return ret
        

    def remove_block_field_data_tuple_id(self, *args):
        """
        remove_block_field_data_tuple_id(self, index:int) -> None
        C++: void remove_block_field_data_tuple_id(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.RemoveBlockFieldDataTupleId, *args)
        return ret

    def remove_block_field_data_tuple_ids(self):
        """
        remove_block_field_data_tuple_ids(self) -> None
        C++: void remove_block_field_data_tuple_ids()"""
        ret = self._vtk_obj.RemoveBlockFieldDataTupleIds()
        return ret
        

    def remove_block_opacities(self):
        """
        remove_block_opacities(self) -> None
        C++: void remove_block_opacities()"""
        ret = self._vtk_obj.RemoveBlockOpacities()
        return ret
        

    def remove_block_opacity(self, *args):
        """
        remove_block_opacity(self, index:int) -> None
        C++: void remove_block_opacity(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.RemoveBlockOpacity, *args)
        return ret

    def remove_block_scalar_mode(self, *args):
        """
        remove_block_scalar_mode(self, index:int) -> None
        C++: void remove_block_scalar_mode(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.RemoveBlockScalarMode, *args)
        return ret

    def remove_block_scalar_modes(self):
        """
        remove_block_scalar_modes(self) -> None
        C++: void remove_block_scalar_modes()"""
        ret = self._vtk_obj.RemoveBlockScalarModes()
        return ret
        

    def remove_block_visibilities(self):
        """
        remove_block_visibilities(self) -> None
        C++: void remove_block_visibilities()"""
        ret = self._vtk_obj.RemoveBlockVisibilities()
        return ret
        

    def remove_block_visibility(self, *args):
        """
        remove_block_visibility(self, index:int) -> None
        C++: void remove_block_visibility(unsigned int index)"""
        ret = self._wrap_call(self._vtk_obj.RemoveBlockVisibility, *args)
        return ret

    _updateable_traits_ = \
    (('color_missing_arrays_with_nan_color',
    'GetColorMissingArraysWithNanColor'), ('pause_shift_scale',
    'GetPauseShiftScale'), ('seamless_u', 'GetSeamlessU'), ('seamless_v',
    'GetSeamlessV'), ('interpolate_scalars_before_mapping',
    'GetInterpolateScalarsBeforeMapping'), ('scalar_visibility',
    'GetScalarVisibility'), ('static', 'GetStatic'),
    ('use_lookup_table_scalar_range', 'GetUseLookupTableScalarRange'),
    ('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('color_mode',
    'GetColorMode'), ('resolve_coincident_topology',
    'GetResolveCoincidentTopology'), ('scalar_mode', 'GetScalarMode'),
    ('cell_id_array_name', 'GetCellIdArrayName'),
    ('composite_id_array_name', 'GetCompositeIdArrayName'),
    ('point_id_array_name', 'GetPointIdArrayName'),
    ('process_id_array_name', 'GetProcessIdArrayName'),
    ('vbo_shift_scale_method', 'GetVBOShiftScaleMethod'), ('ghost_level',
    'GetGhostLevel'), ('number_of_pieces', 'GetNumberOfPieces'),
    ('number_of_sub_pieces', 'GetNumberOfSubPieces'), ('piece',
    'GetPiece'), ('array_access_mode', 'GetArrayAccessMode'),
    ('array_component', 'GetArrayComponent'), ('array_id', 'GetArrayId'),
    ('array_name', 'GetArrayName'), ('field_data_tuple_id',
    'GetFieldDataTupleId'), ('render_time', 'GetRenderTime'),
    ('resolve_coincident_topology_polygon_offset_faces',
    'GetResolveCoincidentTopologyPolygonOffsetFaces'),
    ('resolve_coincident_topology_z_shift',
    'GetResolveCoincidentTopologyZShift'), ('scalar_range',
    'GetScalarRange'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'color_missing_arrays_with_nan_color', 'debug',
    'global_warning_display', 'interpolate_scalars_before_mapping',
    'pause_shift_scale', 'release_data_flag', 'scalar_visibility',
    'seamless_u', 'seamless_v', 'static', 'use_lookup_table_scalar_range',
    'color_mode', 'resolve_coincident_topology', 'scalar_mode',
    'abort_output', 'array_access_mode', 'array_component', 'array_id',
    'array_name', 'cell_id_array_name', 'composite_id_array_name',
    'field_data_tuple_id', 'ghost_level', 'number_of_pieces',
    'number_of_sub_pieces', 'object_name', 'piece', 'point_id_array_name',
    'process_id_array_name', 'progress_text', 'render_time',
    'resolve_coincident_topology_polygon_offset_faces',
    'resolve_coincident_topology_z_shift', 'scalar_range',
    'vbo_shift_scale_method'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(CompositePolyDataMapper, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit CompositePolyDataMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['color_missing_arrays_with_nan_color',
            'interpolate_scalars_before_mapping', 'pause_shift_scale',
            'scalar_visibility', 'seamless_u', 'seamless_v', 'static',
            'use_lookup_table_scalar_range'], ['color_mode',
            'resolve_coincident_topology', 'scalar_mode'], ['abort_output',
            'array_access_mode', 'array_component', 'array_id', 'array_name',
            'cell_id_array_name', 'composite_id_array_name',
            'field_data_tuple_id', 'ghost_level', 'number_of_pieces',
            'number_of_sub_pieces', 'object_name', 'piece', 'point_id_array_name',
            'process_id_array_name', 'render_time',
            'resolve_coincident_topology_polygon_offset_faces',
            'resolve_coincident_topology_z_shift', 'scalar_range',
            'vbo_shift_scale_method']),
            title='Edit CompositePolyDataMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit CompositePolyDataMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

