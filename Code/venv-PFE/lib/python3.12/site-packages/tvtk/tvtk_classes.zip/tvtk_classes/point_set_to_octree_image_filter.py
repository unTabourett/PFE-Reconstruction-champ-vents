# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.partitioned_data_set_algorithm import PartitionedDataSetAlgorithm


class PointSetToOctreeImageFilter(PartitionedDataSetAlgorithm):
    r"""
    PointSetToOctreeImageFilter - convert a point set to an octree
    image
    
    Superclass: PartitionedDataSetAlgorithm
    
    PointSetToOctreeImageFilter is a filter that converts a
    PointSet to an a PartitionedDataset with one ImageData with
    a number of points per cell target.
    
    The reason we output a PartitionedDataset is because the
    WHOLE_EXTENT needs to be dynamic.
    
    The scalars of the ImageData are an octree unsigned char cell data
    array. Each bit of the unsigned char indicates if the point-set had a
    point close to one of the 8 corners of the cell.
    
    It can optionally also output a cell data array based on an input
    point-data scalar array by setting set_input_array_to_process. This array
    will have 1 or many components that represent different functions
    i.e. last value, min, max, count, sum, mean.
    
    @warning
    This class has been threaded with SMPTools. Using TBB or other
    non-sequential type (set in the CMake variable
    VTK_SMP_IMPLEMENTATION_TYPE) may improve performance significantly.
    
    @sa OctreeImageToPointSetFilter
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPointSetToOctreeImageFilter, obj, update, **traits)
    
    compute_count = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get if the count of the values for each cell id of the point
        data array will be computed.
        
        The default is false.
        """
    )

    def _compute_count_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeCount,
                        self.compute_count_)

    compute_last_value = tvtk_base.true_bool_trait(desc=\
        r"""
        Set/Get if the last value for each cell id of the point data
        array will be computed.
        
        The default is false.
        
        Note: Because multithreading is employed the last value
        computation is not deterministic.
        """
    )

    def _compute_last_value_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeLastValue,
                        self.compute_last_value_)

    compute_max = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get if the max value for each cell id of the point data array
        will be computed.
        
        The default is false.
        """
    )

    def _compute_max_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeMax,
                        self.compute_max_)

    compute_mean = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get if the mean value for each cell id of the point data
        array will be computed.
        
        The default is false.
        
        Note: if compute_mean is true, the sum and count will be computed
        regardless if they are on or not.
        """
    )

    def _compute_mean_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeMean,
                        self.compute_mean_)

    compute_min = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get if the min value for each cell id of the point data array
        will be computed.
        
        The default is false.
        """
    )

    def _compute_min_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeMin,
                        self.compute_min_)

    compute_sum = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get if the sum of the values for each cell id of the point
        data array will be computed.
        
        The default is false.
        """
    )

    def _compute_sum_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeSum,
                        self.compute_sum_)

    process_input_point_array = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get if array defined using set_input_array_to_process, which MUST
        be a point data array, will be processed.
        
        The default is off.
        """
    )

    def _process_input_point_array_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetProcessInputPointArray,
                        self.process_input_point_array_)

    number_of_points_per_cell = traits.Trait(1, traits.Range(1, 2147483647, enter_set=True, auto_set=False), desc=\
        r"""
        Specify the average number of points in each cell of the output
        image. This data member is used to determine the number
        dimensions of the output image.
        
        The default is 1.
        """
    )

    def _number_of_points_per_cell_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfPointsPerCell,
                        self.number_of_points_per_cell)

    _updateable_traits_ = \
    (('compute_count', 'GetComputeCount'), ('compute_last_value',
    'GetComputeLastValue'), ('compute_max', 'GetComputeMax'),
    ('compute_mean', 'GetComputeMean'), ('compute_min', 'GetComputeMin'),
    ('compute_sum', 'GetComputeSum'), ('process_input_point_array',
    'GetProcessInputPointArray'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('number_of_points_per_cell', 'GetNumberOfPointsPerCell'),
    ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'compute_count', 'compute_last_value',
    'compute_max', 'compute_mean', 'compute_min', 'compute_sum', 'debug',
    'global_warning_display', 'process_input_point_array',
    'release_data_flag', 'abort_output', 'number_of_points_per_cell',
    'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(PointSetToOctreeImageFilter, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit PointSetToOctreeImageFilter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['compute_count', 'compute_last_value', 'compute_max',
            'compute_mean', 'compute_min', 'compute_sum',
            'process_input_point_array'], [], ['abort_output',
            'number_of_points_per_cell', 'object_name']),
            title='Edit PointSetToOctreeImageFilter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit PointSetToOctreeImageFilter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

