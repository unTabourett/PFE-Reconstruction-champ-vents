# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.pass_input_type_algorithm import PassInputTypeAlgorithm


class ExpandMarkedElements(PassInputTypeAlgorithm):
    r"""
    ExpandMarkedElements - expands marked elements to including
    adjacent elements.
    
    Superclass: PassInputTypeAlgorithm
    
    ExpandMarkedElements is intended to expand selected cells to grow
    to include adjacent cells. The filter works across all blocks in a
    composite dataset and across all ranks. Besides cells, the filter can
    be used to expand selected points instead in which case adjacent
    points are defined as points on any cell that has the source point as
    one of its points.
    
    The selected cells (or points) are indicated by a
    `vtksigned_char_array` on cell-data (or point-data). The array can be
    selected by using `set_input_array_to_process(0, 0, 0,...)` (see
    Algorithm::SetInputArrayToProcess).
    
    Currently, the filter only supports expanding marked elements for
    cells and points.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkExpandMarkedElements, obj, update, **traits)
    
    remove_intermediate_layers = tvtk_base.false_bool_trait(desc=\
        r"""
        Get/Set the flag to remove intermediate layers Default is false.
        """
    )

    def _remove_intermediate_layers_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRemoveIntermediateLayers,
                        self.remove_intermediate_layers_)

    remove_seed = tvtk_base.false_bool_trait(desc=\
        r"""
        Get/Set the flag to remove seed of marked elements. Default is
        false.
        """
    )

    def _remove_seed_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRemoveSeed,
                        self.remove_seed_)

    def _get_controller(self):
        return wrap_vtk(self._vtk_obj.GetController())
    def _set_controller(self, arg):
        old_val = self._get_controller()
        self._wrap_call(self._vtk_obj.SetController,
                        deref_vtk(arg))
        self.trait_property_changed('controller', old_val, arg)
    controller = traits.Property(_get_controller, _set_controller, desc=\
        r"""
        
        """
    )

    number_of_layers = traits.Trait(2, traits.Range(1, 2147483647, enter_set=True, auto_set=False), desc=\
        r"""
        Get/Set the number of layers to expand by. Default is 2.
        """
    )

    def _number_of_layers_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfLayers,
                        self.number_of_layers)

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input data object. This method is not recommended for
        use, but lots of old style filters use it.
        """
    )

    _updateable_traits_ = \
    (('remove_intermediate_layers', 'GetRemoveIntermediateLayers'),
    ('remove_seed', 'GetRemoveSeed'), ('abort_execute',
    'GetAbortExecute'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('number_of_layers', 'GetNumberOfLayers'),
    ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'remove_intermediate_layers', 'remove_seed',
    'abort_output', 'number_of_layers', 'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(ExpandMarkedElements, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit ExpandMarkedElements properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['remove_intermediate_layers', 'remove_seed'], [],
            ['abort_output', 'number_of_layers', 'object_name']),
            title='Edit ExpandMarkedElements properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit ExpandMarkedElements properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

