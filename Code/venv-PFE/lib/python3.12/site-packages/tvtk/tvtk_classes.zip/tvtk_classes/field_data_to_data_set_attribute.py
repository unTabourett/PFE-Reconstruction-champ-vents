# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.pass_input_type_algorithm import PassInputTypeAlgorithm


class FieldDataToDataSetAttribute(PassInputTypeAlgorithm):
    r"""
    FieldDataToDataSetAttribute - map field data to other attribute
    data
    
    Superclass: PassInputTypeAlgorithm
    
    FieldDataToDataSetAttribute is a filter that copies field data
    arrays into another attribute data arrays.
    
    This is done at very low memory cost by using the Implicit Array
    infrastructure.
    
    NOTE: It copies only the first component of the first tuple into a
    ConstantArray. StringArray are not supported.
    
    @sa
    FieldData CellData
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkFieldDataToDataSetAttribute, obj, update, **traits)
    
    process_all_arrays = tvtk_base.true_bool_trait(desc=\
        r"""
        Activate whether to process all input arrays or only the selected
        ones. If false, only arrays selected by the user will be
        considered by this filter. The default is true.
        """
    )

    def _process_all_arrays_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetProcessAllArrays,
                        self.process_all_arrays_)

    output_field_type = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the output attribute type.
        """
    )

    def _output_field_type_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOutputFieldType,
                        self.output_field_type)

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input data object. This method is not recommended for
        use, but lots of old style filters use it.
        """
    )

    def add_field_data_array(self, *args):
        """
        add_field_data_array(self, name:str) -> None
        C++: virtual void add_field_data_array(const char *name)
        Adds an array to be processed. This only has an effect if
        process_all_arrays is off. If the name is already present, nothing
        happens.
        """
        ret = self._wrap_call(self._vtk_obj.AddFieldDataArray, *args)
        return ret

    def clear_field_data_arrays(self):
        """
        clear_field_data_arrays(self) -> None
        C++: virtual void clear_field_data_arrays()
        Removes all arrays to be processed from the list. This only has
        an effect if process_all_arrays is off.
        """
        ret = self._vtk_obj.ClearFieldDataArrays()
        return ret
        

    def remove_field_data_array(self, *args):
        """
        remove_field_data_array(self, name:str) -> None
        C++: virtual void remove_field_data_array(const char *name)
        Removes an array to be processed. This only has an effect if
        process_all_arrays is off. If the name is not present, nothing
        happens.
        """
        ret = self._wrap_call(self._vtk_obj.RemoveFieldDataArray, *args)
        return ret

    _updateable_traits_ = \
    (('process_all_arrays', 'GetProcessAllArrays'), ('abort_execute',
    'GetAbortExecute'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('output_field_type',
    'GetOutputFieldType'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'process_all_arrays', 'release_data_flag', 'abort_output',
    'object_name', 'output_field_type', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(FieldDataToDataSetAttribute, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit FieldDataToDataSetAttribute properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['process_all_arrays'], [], ['abort_output', 'object_name',
            'output_field_type']),
            title='Edit FieldDataToDataSetAttribute properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit FieldDataToDataSetAttribute properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

